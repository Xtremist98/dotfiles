# NordGUI

A theme‑aware **NordVPN GTK4 / libadwaita** front‑end that drives **OpenVPN**
under the hood. Pick any country/server from your own `*.ovpn` configs, watch
live status in a two‑pane window, keep a system‑tray icon in your bar, and — if
you want hard leak protection — flip on a real **firewall kill‑switch**.

No NordVPN account API, no telemetry: it just wraps the OpenVPN configs you
already have. Connection and the kill‑switch are performed by a tiny
**root helper** elevated through `pkexec` + a passwordless `polkit` rule, so you
never type a sudo password to connect.

---

## Features

- **Two‑pane UI** — status / live info on the left, searchable server list on
  the right. Solitude‑dark theme aware (grey accent, no white toggles).
- **Per‑server rows** — one row per `*.ovpn` file, labelled `CC · UDP` /
  `CC · TCP`. Country grouping with collapsible sections.
- **Search** — live filter across server ids and country names.
- **Favorites / pinning** — star any server; pinned servers bubble up into a
  dedicated **Favorites** section at the top.
- **Live status** — public IP, DNS, download/upload rate (sparkline), and
  uptime, refreshed every second.
- **Latency engine** — background ICMP ping with a **TCP‑connect fallback**
  (NordVPN filters ICMP, so TCP to the VPN port is used when ping is blocked).
  Each row shows `NN ms`; unreachable servers show `—`.
- **Sort servers** — by country (default) or by measured latency.
- **Scan latency** — re‑probe on demand from the menu.
- **Auto‑connect on launch** — reconnect to the last server automatically.
- **Firewall kill‑switch** — blocks all outbound traffic unless it flows
  through the tunnel (+ the VPN server itself). Engages on connect, disengages
  on disconnect / quit. `nftables` preferred, `iptables` fallback.
- **In‑app credentials** — store your NordVPN username/password once
  (`~/.config/nordgui/credentials`).
- **Add server files…** — import `*.ovpn` files via a file chooser into
  `~/.config/nordgui/servers/`.
- **System tray** (StatusNotifierItem, Ayatana‑compatible) — green/grey icon,
  left‑click raises the window, right‑click menu shows status + Connect /
  Disconnect / Open / Quit.
- **Single instance** — launching again just focuses the running window.
- **Leak guard** — warns if the app thinks it's "connected" but traffic isn't
  actually on the tunnel.

---

## How it works

```
┌────────────────────────────┐        pkexec        ┌──────────────────────────┐
│  nordvpn-gui  (you, user)  │ ───────────────────▶ │  nordvpn-gui-helper (root)│
│  GTK4 / libadwaita  app    │   connect/disconnect │  • openvpn --config ...   │
│  • tray, map, list, status │   killswitch-on/off   │  • nft/iptables rules     │
└────────────────────────────┘                      └──────────────────────────┘
            │                                                    │
            │  passwordless via polkit rule                     ▼
            │                          tun0  ────────────▶  OpenVPN  ──▶  NordVPN
            ▼
   ~/.config/nordgui/{servers/*.ovpn, credentials, config.json, active.json}
```

### 1. Server discovery
On launch `discover_servers()` scans `~/.config/nordgui/servers/` for files
matching `<cc><n>.nordvpn.com.<udp|tcp>.ovpn`, parses the `remote` line into
`host`/`port`, derives the country from the two‑letter prefix, and builds one
entry per file. UDP and TCP variants of the same server become two rows.

First launch also migrates a legacy layout: `~/nordvpn/*.ovpn` and
`~/.nordvpn-creds` are imported into `~/.config/nordgui/`.

### 2. Connecting (elevation)
Clicking a server calls `_connect()`, which:

1. Records the selection in `config.json` (`last_server` / `last_proto`).
2. Calls `pkexec /usr/local/bin/nordvpn-gui-helper connect <config> <creds> <proto>`.
3. The **helper** (running as root) launches
   `openvpn --config … --auth-user-pass <creds> --block-ipv6 --redirect-gateway def1 --daemon`.
4. The app polls `tun_up()` (an `ip link` check for `tun0`) every second and
   flips the status dot from amber "connecting" to green "connected".

No password is prompted because the `polkit` rule (below) returns `YES` for
exactly that helper binary.

### 3. Security model (polkit + pkexec)
`/usr/local/share/polkit-1/rules.d/50-nordvpn-gui.rules`:

```js
polkit.addRule(function(action, subject) {
    if (action.id != "org.freedesktop.policykit.exec") return;
    var proc = action.lookup("program") || action.lookup("path") ||
               action.lookup("polkit.exec.path");
    if (proc == "/usr/local/bin/nordvpn-gui-helper" &&
        subject.local && subject.active) {
        return polkit.Result.YES;   // passwordless, but ONLY this binary
    }
});
```

The helper must be **root‑owned and `0755`** (pkexec refuses otherwise). It can
only run OpenVPN with the user's own config + credentials and manage the
kill‑switch firewall — nothing else. On a multi‑user box, tighten the
`subject.user` check.

### 4. Firewall kill‑switch
When enabled, `_connect()` resolves the server hostname to an IP (`_resolve()`,
cached) and, after OpenVPN starts, calls
`pkexec … killswitch-on <server-ip>`. The helper installs a strict egress
policy:

- **nftables** (preferred): an `inet nordvpn_gui` table with an `output`
  chain that accepts `lo`, established/related, `oifname tun0`, and
  `ip daddr <server-ip>` — then `reject` everything else.
- **iptables** (fallback): a `nordvpn_gui` chain (hooked into `OUTPUT`)
  with the same accepts, then `REJECT`.

`killswitch-off` flushes the table / chain. It is also called on disconnect
and on app quit, so closing the app never leaves you firewalled off the
internet. If the server IP can't be resolved, the kill‑switch is skipped
(with a toast) rather than installing a broken ruleset.

### 5. Latency engine
`_scan_latency()` fans out pings across all servers with a 24‑worker thread
pool. For each server it first tries ICMP (`ping -c1 -w1`); if that returns
nothing (NordVPN drops ICMP), it falls back to timing a TCP `connect()` to the
VPN `host:port`. Results land in `self.latency` and update each row's label
via `GLib.idle_add`. With **Sort = Latency**, the list re‑orders fastest‑first
after a scan. A scan also runs automatically on launch when latency sorting is
on or no data exists yet.

### 6. System tray
A raw `StatusNotifierItem` (registered at `/org/ayatana/NotificationItem/nordvpn_gui`)
with a `com.canonical.dbusmenu` menu. The menu is rebuilt dynamically (status
line, Disconnect/Connect toggle, Open, Quit) and a live `ToolTip` shows the
current state. Icons are full PNG paths generated from the symbolic SVGs, which
is what the Ayatana watcher (used by the Omarchy bar) actually renders.

---

## Installation

### From the tarball (recommended)

```bash
tar xzf nordgui-1.1.0.tar.gz
cd nordgui-1.1.0
sudo ./install.sh            # installs to /usr/local (use PREFIX=/opt to change)
```

Then launch **nordvpn-gui** from your menu or a terminal.

### From source (git)

```bash
git clone https://github.com/Xtremist98/nordgui.git
cd nordgui
# run directly (no install):
python3 share/nordvpn-gui/nordvpn_gui.py
# or install system‑wide (copies helper + polkit rule, needs root):
sudo ./install.sh
```

### Arch / AUR (PKGBUILD)

```bash
makepkg -si               # builds + installs using the included PKGBUILD
```

The PKGBUILD installs the helper as root‑owned `0755` and drops the polkit
rule into `/usr/local/share/polkit-1/rules.d/`.

### Requirements

`python`, `gtk4`, `libadwaita`, `python-gobject`, `openvpn`, `polkit`,
`rsvg-convert` (tray icon generation), plus `nftables` **or** `iptables` for
the kill‑switch. On Omarchy all are present. A `ping` that works for unprivileged
users (standard on Arch) is needed for latency probing.

---

## First‑run setup

1. Open the app. If you have `~/nordvpn/*.ovpn` + `~/.nordvpn-creds`, they are
   imported automatically into `~/.config/nordgui/`.
2. Otherwise, add your NordVPN **credentials** in the right‑hand panel
   (saved to `~/.config/nordgui/credentials`), then click **Add server files…**
   to import your OpenVPN configs (or drop them into
   `~/.config/nordgui/servers/`).
3. Pick a server and click **Connect**. The first connection just needs the
   polkit rule installed (done by `install.sh`).

---

## Usage

- **Connect / Disconnect** — click a server row, or use the tray menu.
- **Protocol** — `UDP — faster` / `TCP — reliable` (auto‑detected per file,
  switchable from the menu).
- **Auto‑connect on launch** — reconnect to the last server automatically.
- **Firewall kill‑switch** — block all non‑tunnel traffic. Arms immediately if
  already connected; otherwise engages on the next connect.
- **Sort servers** — `Default (by country)` or `Latency (fastest first)`.
- **Scan latency** — re‑probe all servers now.
- **Tray** — left‑click raises the window; right‑click → status / Connect /
  Disconnect / Open / Quit. **Quit** fully disconnects the VPN and removes the
  firewall rules.

---

## Configuration & data files

| Path | Purpose |
|------|---------|
| `~/.config/nordgui/credentials` | `user\npass` for OpenVPN `--auth-user-pass` |
| `~/.config/nordgui/servers/*.ovpn` | imported OpenVPN configs |
| `~/.config/nordgui/config.json` | protocol, auto‑connect, kill‑switch, sort, favorites, last server |
| `~/.config/nordgui/active.json` | currently‑connected server (id, cc, ip, started) |
| `/usr/local/bin/nordvpn-gui-helper` | root OpenVPN + firewall helper (pkexec) |
| `/usr/local/share/polkit-1/rules.d/50-nordvpn-gui.rules` | passwordless elevation rule |

---

## Troubleshooting

- **Connect asks for a password / is refused** — the polkit rule isn't
  installed or the helper isn't root‑owned `0755`. Re‑run `sudo ./install.sh`.
- **Kill‑switch enabled but no internet even after disconnect** — the helper
  failed to flush. Run `sudo nft delete table inet nordvpn_gui` (or
  `sudo iptables -F nordvpn_gui && sudo iptables -X nordvpn_gui`).
- **Latency shows `—` for everything** — ICMP is blocked *and* the TCP fallback
  couldn't connect (server down / port filtered). Expected for some hosts.
- **Tray icon missing in the bar** — the bar's SNI host is Ayatana; the app
  registers at `/org/ayatana/NotificationItem/nordvpn_gui`. A stale instance
  can hold the slot — quit fully (tray → Quit) and relaunch.
- **Single‑instance "old window"** — launching again just focuses the running
  process. To get a fresh process, Quit first.

---

## License

MIT — see [LICENSE](LICENSE).
