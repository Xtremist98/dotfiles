#!/usr/bin/env python3
"""NordVPN GUI — a small, theme-aware (Omarchy/solitude) OpenVPN front-end.

Reads *.ovpn configs from ~/nordvpn, connects via openvpn through a root
helper (passwordless via polkit), and shows status / IP / DNS / live speed
in a libadwaita window + system tray.
"""

import os
import re
import json
import shutil
import subprocess
import threading
import time
import math
import warnings

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import (  # noqa: E402
    Gtk,
    Gdk,
    Adw,
    Gio,
    GLib,
    GdkPixbuf,
    Pango,
)
import cairo  # noqa: E402

ICON_DIR = os.path.expanduser("~/.local/share/icons/hicolor/scalable/status")
# Generated PNGs go to a user-writable dir; source SVGs may live in the user
# dir OR the system install dir (when installed via the package).
ICON_PNG_DIR = os.path.expanduser("~/.local/share/nordvpn-gui/icons")
_ICON_SRC_CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons"),
    os.path.expanduser("~/.local/share/nordvpn-gui/icons"),
    "/usr/local/share/nordvpn-gui/icons",
    "/usr/share/nordvpn-gui/icons",
]


def _icon_src_dir():
    for d in _ICON_SRC_CANDIDATES:
        if os.path.isdir(d):
            return d
    return _ICON_SRC_CANDIDATES[0]

APP_ID = "com.linuxer.NordvpnGui"
# Single base folder for everything (was ~/nordvpn + ~/.nordvpn-creds before).
NORDGUI_DIR = os.path.expanduser("~/.config/nordgui")
SERVERS_DIR = os.path.join(NORDGUI_DIR, "servers")
CREDS_FILE = os.path.join(NORDGUI_DIR, "credentials")
CONFIG_DIR = NORDGUI_DIR
ACTIVE_FILE = os.path.join(NORDGUI_DIR, "active.json")
SETTINGS_FILE = os.path.join(NORDGUI_DIR, "config.json")
HELPER = "/usr/local/bin/nordvpn-gui-helper"

# Legacy locations we migrate from on first run.
LEGACY_OVPN_DIR = os.path.expanduser("~/nordvpn")
LEGACY_CREDS_FILE = os.path.expanduser("~/.nordvpn-creds")

COUNTRY_NAMES = {
    "ae": "United Arab Emirates", "ca": "Canada", "ch": "Switzerland",
    "de": "Germany", "es": "Spain", "fr": "France", "in": "India",
    "it": "Italy", "lk": "Sri Lanka", "nl": "Netherlands", "no": "Norway",
    "np": "Nepal", "pk": "Pakistan", "ro": "Romania", "se": "Sweden",
    "th": "Thailand", "tr": "Turkey", "uk": "United Kingdom",
    "us": "United States", "vn": "Vietnam",
}

# Equirectangular world-map texture size (must match the generated PNG).
MAP_W, MAP_H = 1000, 500

# Approximate centroid (lat, lon) per country code, used to place the marker.
COUNTRY_COORDS = {
    "ae": (24, 54), "ca": (56, -106), "ch": (46.8, 8.2), "de": (51, 10),
    "es": (40, -4), "fr": (46, 2), "in": (22, 79), "it": (42, 12),
    "lk": (7.8, 80.8), "nl": (52.2, 5.3), "no": (61, 9), "np": (28, 84),
    "pk": (30, 70), "ro": (46, 25), "se": (62, 15), "th": (15, 101),
    "tr": (39, 35), "uk": (54, -2), "us": (38, -97), "vn": (16, 106),
}

# Continent each country belongs to (for map labels).
COUNTRY_CONTINENT = {
    "ae": "Asia", "ca": "North America", "ch": "Europe", "de": "Europe",
    "es": "Europe", "fr": "Europe", "in": "Asia", "it": "Europe",
    "lk": "Asia", "nl": "Europe", "no": "Europe", "np": "Asia",
    "pk": "Asia", "ro": "Europe", "se": "Europe", "th": "Asia",
    "tr": "Asia", "uk": "Europe", "us": "North America", "vn": "Asia",
}

# Approximate label anchor (lat, lon) for each continent header on the map.
CONTINENT_COORDS = {
    "Europe": (54, 18),
    "Asia": (40, 95),
    "North America": (48, -100),
}


def country_of(sid):
    """Map a server id like 'us1234' to its country name."""
    if not sid:
        return None
    m = re.match(r"([a-z]{2})", sid)
    if not m:
        return sid
    return COUNTRY_NAMES.get(m.group(1), m.group(1).upper())

CSS = b"""
.status-dot { min-width: 16px; min-height: 16px; }

/* ---- panes ---- */
.pane-left {
    background: linear-gradient(180deg, #14181b 0%, #0c0e10 100%);
    background-color: #0c0e10;
    border: 1px solid rgba(202, 204, 204, 0.06);
    border-radius: 18px;
}
.pane-right {
    /* transparent so the world-map background layer shows through */
    background-color: transparent;
}

/* Keep the server-list scrollbar (and its up/down stepper arrows) clear of
   the panel edge and the list content. Thinner at rest, still expands on
   hover (that behaviour is driven by GTK4/libadwaita). */
.list-scroll scrollbar.vertical {
    min-width: 4px;
    margin-left: 8px;
    margin-top: 4px;
    margin-bottom: 4px;
}
.list-scroll scrollbar.vertical slider {
    min-width: 4px;
    border-radius: 5px;
}

/* ---- hero / status card ---- */
.card {
    background: linear-gradient(160deg, #14181b 0%, #0c0e10 100%);
    border: 1px solid rgba(202, 204, 204, 0.08);
    border-radius: 18px;
    padding: 16px;
}
.card.connected {
    border-color: rgba(121, 129, 134, 0.6);
    box-shadow: 0 0 0 1px rgba(121, 129, 134, 0.25),
                0 10px 30px rgba(0, 0, 0, 0.45),
                inset 0 0 24px rgba(121, 129, 134, 0.06);
}

.hero-title { font-size: 21px; font-weight: 800; letter-spacing: -0.02em; }
.hero-sub { font-size: 12px; color: #798186; }

.btn-connect {
    padding: 11px;
    font-weight: 700;
    font-size: 14px;
    border-radius: 13px;
    background-color: #3584e4;
    color: #ffffff;
}
.btn-connect:hover { background-color: #4190ec; }
.btn-disconnect {
    padding: 11px;
    font-weight: 700;
    font-size: 14px;
    border-radius: 13px;
    background-color: #e5484d;
    color: #ffffff;
}
.btn-disconnect:hover { background-color: #ec4d52; }
.fastest-btn {
    padding: 11px;
    font-weight: 600;
    font-size: 13px;
    border-radius: 13px;
    background-color: #2f3a44;
    color: #cacccc;
}
.fastest-btn:hover { background-color: #3a4752; }
.fastest-btn:disabled { opacity: 0.5; }

.btn-add {
    padding: 11px;
    font-weight: 600;
    font-size: 13px;
    border-radius: 13px;
    background-color: #2f3a44;
    color: #cacccc;
}
.btn-add:hover { background-color: #3a4752; }

/* ---- info card ---- */
.info-card {
    background-color: #0c0e10;
    border: 1px solid rgba(202, 204, 204, 0.08);
    border-radius: 18px;
    padding: 6px 12px;
}

.mono { font-family: monospace; font-size: 13px; }
.dl { color: #9fa5a9; }   /* theme green */
.ul { color: #798186; }   /* theme blue  */

/* ---- servers ---- */
.server-row { padding: 6px 10px; border-radius: 10px; }
.server-row.accent {
    background-color: rgba(121, 129, 134, 0.20);
    box-shadow: inset 3px 0 0 0 #798186;
}
.server-row:hover { background-color: rgba(202, 204, 204, 0.06); }

.search { border-radius: 12px; }

.expander { border-radius: 12px; }
.expander:hover { background-color: rgba(202, 204, 204, 0.04); }

/* pinned fastest row pop */
.fastest-row {
    background: linear-gradient(90deg, rgba(121,129,134,0.18), rgba(121,129,134,0.04));
    box-shadow: inset 3px 0 0 0 #798186;
}
.fastest-row:hover { background: linear-gradient(90deg, rgba(121,129,134,0.26), rgba(121,129,134,0.06)); }

/* live bandwidth sparkline */
.spark { border-radius: 10px; background-color: rgba(202, 204, 204, 0.04); }
"""


# --------------------------------------------------------------------------
# Server discovery
# --------------------------------------------------------------------------
def _parse_remote(path):
    """Return (host, port) from the ovpn `remote` line, or (None, None)."""
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("remote"):
                    parts = line.split()
                    if len(parts) >= 2:
                        host = parts[1]
                        port = int(parts[2]) if len(parts) >= 3 else 1194
                        return host, port
    except OSError:
        pass
    return None, 1194


def discover_servers():
    """Return a dict: country_name -> list of server dicts.

    Every *.ovpn file is its own entry (one row). A server id that ships as
    both protocols shows TWO rows — e.g. ``ca1564 · UDP`` and ``ca1564 · TCP``
    — so the user can clearly pick the exact protocol. Filename pattern
    tolerates NordVPN exports:
        <id>.nordvpn.com.<udp|tcp>[_2.6].ovpn
    """
    servers = {}
    if not os.path.isdir(SERVERS_DIR):
        return servers
    pat = re.compile(
        r"^(?P<id>[a-z]{2}(?:-[a-z0-9]+)?\d*)\.nordvpn\.com\."
        r"(?P<proto>udp|tcp)(?:_\d+\.\d+)?\.ovpn$")
    for name in sorted(os.listdir(SERVERS_DIR)):
        m = pat.match(name)
        if not m:
            continue
        sid = m.group("id")
        proto = m.group("proto")
        cc = re.match(r"[a-z]{2}", sid).group(0)
        cname = COUNTRY_NAMES.get(cc, cc.upper())
        full = os.path.join(SERVERS_DIR, name)
        host, port = _parse_remote(full)
        entry = {
            "id": sid,
            "cc": cc,
            "proto": proto,
            "path": full,
            "host": host,
            "port": port,
            "ip": None,   # resolved lazily (see _resolve)
        }
        servers.setdefault(cname, []).append(entry)
    return servers


def migrate_legacy():
    """First-run migration from the old scattered locations into ~/.config/nordgui."""
    os.makedirs(SERVERS_DIR, exist_ok=True)
    # credentials
    if not os.path.exists(CREDS_FILE) and os.path.exists(LEGACY_CREDS_FILE):
        try:
            shutil.copyfile(LEGACY_CREDS_FILE, CREDS_FILE)
        except OSError:
            pass
    # server files
    if os.path.isdir(LEGACY_OVPN_DIR):
        seen = {f.lower() for f in os.listdir(SERVERS_DIR)}
        for name in os.listdir(LEGACY_OVPN_DIR):
            if name.lower().endswith(".ovpn") and name.lower() not in seen:
                try:
                    shutil.copyfile(os.path.join(LEGACY_OVPN_DIR, name),
                                    os.path.join(SERVERS_DIR, name))
                    seen.add(name.lower())
                except OSError:
                    pass


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def fmt_speed(bps):
    if bps < 1000:
        return f"{bps:.0f} B/s"
    k = bps / 1000
    if k < 1000:
        return f"{k:.1f} KB/s"
    return f"{k / 1000:.2f} MB/s"


def tun_up():
    try:
        with open("/sys/class/net/tun0/operstate") as f:
            return f.read().strip() == "up"
    except OSError:
        return False


def openvpn_pid():
    try:
        out = subprocess.run(["pgrep", "-x", "openvpn"],
                             capture_output=True, text=True, timeout=3)
        pids = out.stdout.split()
        return int(pids[0]) if pids else None
    except Exception:
        return None


def openvpn_server_id():
    """Best-effort: derive the connected server id from the running openvpn cmdline."""
    pid = openvpn_pid()
    if not pid:
        return None
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            args = f.read().split(b"\x00")
        args = [a.decode("utf-8", "ignore") for a in args]
        if "--config" in args:
            cfg = args[args.index("--config") + 1]
            base = os.path.basename(cfg)
            m = re.match(r"^(?P<id>[a-z]{2}(?:-[a-z0-9]+)?\d*)\.nordvpn\.com", base)
            return m.group("id") if m else None
    except OSError:
        pass
    return None


def openvpn_uptime():
    pid = openvpn_pid()
    if not pid:
        return None
    try:
        out = subprocess.run(["ps", "-o", "etimes=", "-p", str(pid)],
                             capture_output=True, text=True, timeout=3)
        s = out.stdout.strip()
        return int(s) if s.isdigit() else None
    except Exception:
        return None


def tun_stats():
    try:
        rx = int(open("/sys/class/net/tun0/statistics/rx_bytes").read())
        tx = int(open("/sys/class/net/tun0/statistics/tx_bytes").read())
        return rx, tx
    except OSError:
        return None, None


def read_dns():
    servers = []
    try:
        with open("/etc/resolv.conf") as f:
            for line in f:
                line = line.strip()
                if line.startswith("nameserver"):
                    servers.append(line.split()[1])
    except OSError:
        pass
    return ", ".join(servers) if servers else "—"


def fetch_public_ip():
    try:
        out = subprocess.run(
            ["curl", "-s", "--max-time", "6", "https://api.ipify.org"],
            capture_output=True, text=True, timeout=8,
        )
        return out.stdout.strip() or "—"
    except Exception:
        return "—"


def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# --------------------------------------------------------------------------
# System tray via StatusNotifierItem + dbusmenu (Gio DBus, GTK-version agnostic)
# --------------------------------------------------------------------------
SNI_XML = """
<node>
  <interface name="org.kde.StatusNotifierItem">
    <property name="Category" type="s" access="read"/>
    <property name="Id" type="s" access="read"/>
    <property name="Title" type="s" access="read"/>
    <property name="Status" type="s" access="read"/>
    <property name="IconName" type="s" access="read"/>
    <property name="IconPixmap" type="a(iiay)" access="read"/>
    <property name="IconThemePath" type="s" access="read"/>
    <property name="ToolTip" type="(sa(iiay)ss)" access="read"/>
    <property name="Menu" type="o" access="read"/>
    <method name="Activate"><arg name="x" type="i" direction="in"/><arg name="y" type="i" direction="in"/></method>
    <method name="ContextMenu"><arg name="x" type="i" direction="in"/><arg name="y" type="i" direction="in"/></method>
    <method name="Scroll"><arg name="delta" type="i" direction="in"/><arg name="orientation" type="s" direction="in"/></method>
    <signal name="NewIcon"/>
    <signal name="NewStatus"><arg name="status" type="s"/></signal>
    <signal name="NewToolTip"/>
  </interface>
</node>
"""

DBUSMENU_XML = """
<node>
  <interface name="com.canonical.dbusmenu">
    <method name="GetLayout">
      <arg name="parentId" type="i" direction="in"/>
      <arg name="recursionDepth" type="i" direction="in"/>
      <arg name="propertyNames" type="as" direction="in"/>
      <arg name="revision" type="u" direction="out"/>
      <arg name="layout" type="(ia{sv}av)" direction="out"/>
    </method>
    <method name="Event">
      <arg name="id" type="i" direction="in"/>
      <arg name="eventId" type="s" direction="in"/>
      <arg name="data" type="v" direction="in"/>
      <arg name="timestamp" type="u" direction="in"/>
    </method>
    <method name="AboutToShow"><arg name="id" type="i" direction="in"/><arg name="needUpdate" type="b" direction="out"/></method>
    <property name="Version" type="i" access="read"/>
    <property name="Status" type="s" access="read"/>
    <property name="TextDirection" type="s" access="read"/>
    <signal name="LayoutUpdated"><arg name="revision" type="u"/><arg name="parent" type="i"/></signal>
  </interface>
</node>
"""


class Tray:
    def __init__(self, on_open, on_disconnect, on_quit,
                 get_status=None, on_toggle=None):
        self.on_open = on_open
        self.on_disconnect = on_disconnect
        self.on_quit = on_quit
        self.get_status = get_status
        self.on_toggle = on_toggle
        self.icon = "nordvpn-off-symbolic"
        self.status = "Active"
        self.revision = 1
        self._pixcache = {}
        self.conn = Gio.bus_get_sync(Gio.BusType.SESSION)
        self.sni = Gio.DBusNodeInfo.new_for_xml(SNI_XML).interfaces[0]
        self.menu = Gio.DBusNodeInfo.new_for_xml(DBUSMENU_XML).interfaces[0]
        # Standard StatusNotifierItem bus name + object path. The bar's SNI host
        # (Ayatana/KDE) looks the item up at <bus>/StatusNotifierItem, so we must
        # export there — not on the ayatana NotificationItem path (which the host
        # never queries, so the icon silently never appears).
        self.bus_name = f"org.kde.StatusNotifierItem-{os.getpid()}-1"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            self.conn.register_object(
                "/StatusNotifierItem", self.sni,
                self._sni_method, self._sni_get, None)
            self.conn.register_object("/Menu", self.menu,
                                      self._menu_method, self._menu_get, None)
        self.conn.call_sync(
            "org.freedesktop.DBus", "/org/freedesktop/DBus",
            "org.freedesktop.DBus", "RequestName",
            GLib.Variant("(su)", (self.bus_name, 0x4)),  # replace existing
            None, Gio.DBusCallFlags.NONE, -1, None,
        )
        # Register with the watcher if present
        self._register_watcher()
        # Re-register whenever the watcher (re)appears (e.g. bar restarts)
        self.conn.signal_subscribe(
            "org.freedesktop.DBus", "org.freedesktop.DBus",
            "NameOwnerChanged", "/org/freedesktop/DBus", None,
            Gio.DBusSignalFlags.NONE, self._on_name_owner_changed, None,
        )

    def _register_watcher(self):
        self.conn.call(
            "org.kde.StatusNotifierWatcher", "/StatusNotifierWatcher",
            "org.kde.StatusNotifierWatcher", "RegisterStatusNotifierItem",
            GLib.Variant("(s)", (self.bus_name,)), None,
            Gio.DBusCallFlags.NONE, -1, None, None,
        )

    def _on_name_owner_changed(self, conn, sender, path, iface, signal, params, data):
        name, old_owner, new_owner = params[0], params[1], params[2]
        if name == "org.kde.StatusNotifierWatcher" and new_owner != "":
            self._register_watcher()

    def set_connected(self, c):
        icon = "nordvpn-on-symbolic" if c else "nordvpn-off-symbolic"
        if icon != self.icon:
            self.icon = icon
            self.conn.emit_signal(None, "/StatusNotifierItem",
                                  "org.kde.StatusNotifierItem", "NewIcon",
                                  GLib.Variant("()", ()))

    @staticmethod
    def _icon_path(name):
        base = name.replace("-symbolic", "")
        return os.path.join(_icon_src_dir(), base + "-64.png")

    def _icon_pixmap(self, name):
        if name in self._pixcache:
            return self._pixcache[name]
        path = os.path.join(ICON_DIR, name + ".svg")
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 32, 32, True)
            w, h = pb.get_width(), pb.get_height()
            px = pb.get_pixels()
            stride = pb.get_rowstride()
            buf = bytearray()
            for y in range(h):
                row = px[y * stride:(y * stride) + w * 4]
                for x in range(w):
                    o = x * 4
                    # SNI IconPixmap is ARGB32: emit B,G,R,A so a host that
                    # memcpys into QImage::Format_ARGB32 gets correct colors.
                    buf += bytes((row[o + 2], row[o + 1], row[o], row[o + 3]))
            v = GLib.Variant("a(iiay)", [(w, h, GLib.Variant("ay", bytes(buf)))])
        except Exception:
            v = GLib.Variant("a(iiay)", [])
        self._pixcache[name] = v
        return v

    def _sni_get(self, conn, sender, path, iface, prop):
        if prop == "Category":
            return GLib.Variant("s", "Network")
        if prop == "Id":
            return GLib.Variant("s", "nordvpn-gui")
        if prop == "Title":
            return GLib.Variant("s", "NordVPN")
        if prop == "Status":
            return GLib.Variant("s", self.status)
        if prop == "IconName":
            return GLib.Variant("s", self._icon_path(self.icon))
        if prop == "IconPixmap":
            return self._icon_pixmap(self.icon)
        if prop == "IconThemePath":
            return GLib.Variant("s", ICON_DIR)
        if prop == "ToolTip":
            st = (self.get_status() if self.get_status
                  else {"connected": False, "label": "NordVPN"})
            return GLib.Variant("(sa(iiay)ss)", ("", [], "", st["label"]))
        if prop == "Menu":
            return GLib.Variant("o", "/Menu")
        return None

    def _sni_method(self, conn, sender, path, iface, method, params, inv):
        if method in ("Activate", "ContextMenu"):
            GLib.idle_add(self.on_open)
        inv.return_value(None)

    def _menu_items(self):
        st = (self.get_status() if self.get_status
              else {"connected": False, "label": "NordVPN"})
        items = [{"id": 1, "label": st["label"], "enabled": False, "cb": None}]
        if st["connected"]:
            items.append({"id": 2, "label": "Disconnect",
                          "enabled": True, "cb": self.on_disconnect})
        else:
            items.append({"id": 2, "label": "Connect",
                          "enabled": True, "cb": self.on_toggle})
        items.append({"id": 3, "label": "Open",
                      "enabled": True, "cb": self.on_open})
        items.append({"id": 4, "label": "Quit",
                      "enabled": True, "cb": self.on_quit})
        return items

    def _menu_get(self, conn, sender, path, iface, prop):
        if prop == "Version":
            return GLib.Variant("i", 3)
        if prop == "Status":
            return GLib.Variant("s", "normal")
        if prop == "TextDirection":
            return GLib.Variant("s", "ltr")
        return None

    def _node_variant(self, nid, label, children, props=None):
        b = GLib.VariantBuilder.new(GLib.VariantType("(ia{sv}av)"))
        b.add_value(GLib.Variant("i", nid))
        db = GLib.VariantBuilder.new(GLib.VariantType("a{sv}"))
        if label is not None:
            db.add_value(GLib.Variant("{sv}", ("label", GLib.Variant("s", label))))
        if props:
            for k, v in props.items():
                db.add_value(GLib.Variant("{sv}", (k, v)))
        b.add_value(db.end())
        cb = GLib.VariantBuilder.new(GLib.VariantType("av"))
        for ch in children:
            cb.add_value(GLib.Variant("v", ch))
        b.add_value(cb.end())
        return b.end()

    def _layout(self):
        children = [
            self._node_variant(
                item["id"], item["label"], [],
                {"enabled": GLib.Variant("b", item.get("enabled", True))})
            for item in self._menu_items()
        ]
        return self._node_variant(0, None, children)

    def update_layout(self):
        """Bump the menu revision and tell the host to re-fetch the layout."""
        self.revision += 1
        try:
            self.conn.emit_signal(
                None, "/Menu", "com.canonical.dbusmenu", "LayoutUpdated",
                GLib.Variant("(ui)", (self.revision, 0)))
        except Exception:
            pass

    def _menu_method(self, conn, sender, path, iface, method, params, inv):
        if method == "GetLayout":
            outer = GLib.VariantBuilder.new(GLib.VariantType("(u(ia{sv}av))"))
            outer.add_value(GLib.Variant("u", self.revision))
            outer.add_value(self._layout())
            inv.return_value(outer.end())
        elif method == "AboutToShow":
            inv.return_value(GLib.Variant("(b)", (False,)))
        elif method == "Event":
            mid, evid = params[0], params[1]
            if evid == "clicked":
                for item in self._menu_items():
                    if item["id"] == mid and item.get("cb"):
                        GLib.idle_add(item["cb"])
                        break
            inv.return_value(None)
        else:
            inv.return_value(None)


# --------------------------------------------------------------------------
# Status dot
# --------------------------------------------------------------------------
class StatusDot(Gtk.DrawingArea):
    def __init__(self):
        super().__init__()
        self.set_size_request(14, 14)
        self.state = "disconnected"  # disconnected | connecting | connected
        self._pulse = 0.0
        self._tick_id = None
        self.set_draw_func(self._draw)

    def set_state(self, state):
        if state == self.state:
            return
        self.state = state
        self.queue_draw()
        if state == "connecting" and self._tick_id is None:
            self._tick_id = self.add_tick_callback(self._pulse_tick)
        elif state != "connecting" and self._tick_id is not None:
            self.remove_tick_callback(self._tick_id)
            self._tick_id = None

    def _pulse_tick(self, widget, clock):
        self._pulse = (clock.get_frame_time() / 1e6) % 1.0
        self.queue_draw()
        return self.state == "connecting"

    def _draw(self, area, cr, w, h, *args):
        if self.state == "connected":
            r, g, b = 0x3F / 255, 0xD0 / 255, 0x6B / 255  # vivid green
        elif self.state == "connecting":
            r, g, b = 0xC9 / 255, 0x9E / 255, 0x45 / 255  # amber
        else:
            r, g, b = 0x6B / 255, 0x6E / 255, 0x72 / 255  # muted grey
        a = 1.0
        if self.state == "connecting":
            a = 0.45 + 0.55 * (0.5 + 0.5 * math.sin(self._pulse * 2 * math.pi))
        cr.set_source_rgba(r, g, b, a)
        cr.arc(w / 2, h / 2, min(w, h) / 2 - 1, 0, 2 * math.pi)
        cr.fill()


# --------------------------------------------------------------------------
# Main application
# --------------------------------------------------------------------------
class NordVPN(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=0)
        self.servers = discover_servers()
        self.settings = load_json(SETTINGS_FILE)
        self.favorites = set(self.settings.get("favorites", []))
        self.proto = self.settings.get("proto", "udp")  # udp | tcp
        self.selected = self.settings.get("last_server")
        self.selected_entry = None
        self.active = load_json(ACTIVE_FILE)
        self.ip_cache = None
        self.ip_cache_ts = 0
        self.prev_rx = None
        self.prev_tx = None
        self.prev_ts = None
        self.server_rows = []        # (server_id, country_name, actionrow)
        self.country_expanders = {}  # country_name -> ExpanderRow
        self.indicator = None
        self._connecting = False
        self.dl_hist = []
        self.ul_hist = []
        self._leak_warned = False
        self.latency = {}            # server_id -> ms (float) or None
        self._latency_labels = {}    # server_id -> Gtk.Label
        self.sort_mode = self.settings.get("sort", "default")  # default | latency
        self.kill_switch = bool(self.settings.get("kill_switch", False))

    # ----- lifecycle -----
    def _install_tray_icons(self):
        # The bar's SNI host (Ayatana/Qt) resolves IconName via the active Qt
        # icon theme (Papirus-Dark). Make sure our icons exist there.
        src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")
        themes = ("Papirus-Dark", "Papirus", "hicolor")
        for name in ("nordvpn-on-symbolic.svg", "nordvpn-off-symbolic.svg"):
            s = os.path.join(src, name)
            if not os.path.exists(s):
                continue
            for theme in themes:
                d = os.path.expanduser(
                    f"~/.local/share/icons/{theme}/scalable/status")
                try:
                    os.makedirs(d, exist_ok=True)
                    shutil.copyfile(s, os.path.join(d, name))
                except Exception:
                    pass

    def do_activate(self):
        self._install_tray_icons()
        migrate_legacy()
        if getattr(self, "window", None) is None:
            self._build_ui()
            self._build_tray()
            GLib.timeout_add_seconds(1, self._tick)
            # auto-connect to the last server if the user enabled it
            if self.settings.get("auto_connect") and self.selected_entry:
                GLib.timeout_add(800, lambda: self._connect(self.selected_entry)
                                 or False)
            # background latency scan so rows can be sorted by speed
            if self.settings.get("sort") == "latency" or not self.latency:
                threading.Thread(target=self._scan_latency, daemon=True).start()
        self.window.present()

    # ----- UI -----
    def _build_ui(self):
        self.window = Adw.ApplicationWindow(application=self, title="NordVPN")
        self.window.set_default_size(900, 720)
        # Keep a minimum size so the fixed left column is never squeezed away
        # when the window is tiled (half / third / quarter of the screen).
        self.window.set_size_request(720, 600)
        self.window.connect("close-request", self._on_close)

        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

        toast = Adw.ToastOverlay()
        self.window.set_content(toast)
        self.toast = toast

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        toast.set_child(root)

        # Header
        hb = Adw.HeaderBar()
        hb.set_title_widget(Gtk.Label(label="NordVPN"))
        menu_btn = Gtk.MenuButton()
        menu_btn.set_icon_name("open-menu-symbolic")
        menu_btn.set_popover(self._build_menu())
        hb.pack_end(menu_btn)
        root.append(hb)

        # Two-column layout: status/info (LEFT) | servers (RIGHT).
        # A plain Box — not a Paned — means there is no draggable divider line.
        # The left column width is a FRACTION of the window (see
        # _on_size_allocate) so it stays ~1/3 at any size — never half, even
        # when the window is tiled narrow (quarter / third of the screen).
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        body.set_vexpand(True)
        body.set_margin_start(16)
        body.set_margin_end(16)
        body.set_margin_bottom(16)
        root.append(body)

        # ---------- LEFT: status + connection info ----------
        # `left` is a transparent wrapper; the visual panel is an inner box so
        # its margin is reliably honored and nothing clips the edge.
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        left.set_vexpand(True)
        self._left = left
        self._left_w = 0

        pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        pane.add_css_class("pane-left")
        pane.set_margin_top(12)
        pane.set_margin_bottom(12)
        pane.set_margin_start(12)
        pane.set_margin_end(12)
        pane.set_vexpand(True)
        left.append(pane)

        # status card
        self.card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.card.add_css_class("card")
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.card.append(inner)

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        head.set_valign(Gtk.Align.CENTER)
        self.dot = StatusDot()
        head.append(self.dot)
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.status_label = Gtk.Label(label="Disconnected")
        self.status_label.add_css_class("hero-title")
        self.status_label.set_halign(Gtk.Align.START)
        title_box.append(self.status_label)
        self.status_sub = Gtk.Label(label="No server selected")
        self.status_sub.add_css_class("hero-sub")
        self.status_sub.set_halign(Gtk.Align.START)
        title_box.append(self.status_sub)
        head.append(title_box)
        inner.append(head)

        self.big_btn = Gtk.Button(label="Connect")
        self.big_btn.add_css_class("btn-connect")
        self.big_btn.connect("clicked", self._on_big_btn)
        inner.append(self.big_btn)
        pane.append(self.card)

        # info card
        info_wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        info_wrap.add_css_class("info-card")
        info = Adw.PreferencesGroup()
        info.set_title("Connection")
        self.lbl_server = Gtk.Label(label="—")
        self.lbl_ip = Gtk.Label(label="—")
        self.lbl_dns = Gtk.Label(label="—")
        self.lbl_dl = Gtk.Label(label="—")
        self.lbl_ul = Gtk.Label(label="—")
        self.lbl_up = Gtk.Label(label="—")
        for title, lbl, cls in (
            ("Server", self.lbl_server, None),
            ("Public IP", self.lbl_ip, None),
            ("DNS", self.lbl_dns, None),
            ("Download", self.lbl_dl, "dl"),
            ("Upload", self.lbl_ul, "ul"),
            ("Uptime", self.lbl_up, None),
        ):
            row = Adw.ActionRow(title=title)
            row.set_activatable(title == "Public IP")
            lbl.add_css_class("mono")
            lbl.set_ellipsize(Pango.EllipsizeMode.END)
            if cls:
                lbl.add_css_class(cls)
            if title == "Public IP":
                row.set_tooltip_text("Click to copy")
                row.connect("activated", self._copy_ip)
            row.add_suffix(lbl)
            info.add(row)
        info_wrap.append(info)
        pane.append(info_wrap)

        # live bandwidth sparkline
        spark_lbl = Gtk.Label(label="Traffic (last minute)")
        spark_lbl.add_css_class("hero-sub")
        spark_lbl.set_halign(Gtk.Align.START)
        pane.append(spark_lbl)
        self._spark = Gtk.DrawingArea()
        self._spark.set_size_request(-1, 48)
        self._spark.add_css_class("spark")
        self._spark.set_draw_func(self._draw_spark)
        pane.append(self._spark)

        # ---------- RIGHT: credentials + servers + search ----------
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        right.set_vexpand(True)
        right.add_css_class("pane-right")
        right.set_margin_top(20)
        right.set_margin_bottom(20)
        right.set_margin_start(20)
        right.set_margin_end(24)

        # Credentials (in-app setup) — shown above the server list.
        self._creds_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        right.append(self._creds_box)
        self._build_credentials_widgets()

        # Add server files (opens a file chooser -> copies into the base folder)
        self._add_btn = Gtk.Button(label="Add server files…")
        self._add_btn.add_css_class("btn-add")
        self._add_btn.connect("clicked", self._on_add_servers)
        right.append(self._add_btn)

        rhead = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        rtitle = Gtk.Label(label="Servers")
        rtitle.add_css_class("title-4")
        rhead.append(rtitle)
        right.append(rhead)

        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search country or server…")
        self.search.add_css_class("search")
        self.search.connect("search-changed", self._on_search)
        right.append(self.search)

        list_scroll = Gtk.ScrolledWindow(vexpand=True)
        list_scroll.add_css_class("list-scroll")
        list_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.loc_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.loc_box.set_margin_end(16)
        list_scroll.set_child(self.loc_box)
        right.append(list_scroll)

        left.set_hexpand(False)
        right.set_hexpand(True)

        # ---- world-map background layer for the right (servers) panel ----
        # The map lives in an aspect-correct 2:1 band (AspectFrame) so the
        # WHOLE world is visible (no cropping) and the marker aligns to it.
        self._map_pic = Gtk.Picture()
        self._map_pic.set_hexpand(True)
        self._map_pic.set_vexpand(True)
        self._map_pic.set_can_shrink(True)
        self._map_pic.set_content_fit(Gtk.ContentFit.FILL)
        self._map_pic.set_opacity(0)
        mp = os.path.join(_icon_src_dir(), "world_map.png")
        if os.path.exists(mp):
            try:
                tex = Gdk.Texture.new_from_file(Gio.File.new_for_path(mp))
                if tex:
                    self._map_pic.set_paintable(tex)
            except Exception:
                pass

        self._map_marker = Gtk.DrawingArea()
        self._map_marker.set_hexpand(True)
        self._map_marker.set_vexpand(True)
        self._map_marker.set_draw_func(self._draw_marker)

        # inner overlay: map image + marker, both sharing the 2:1 box so the
        # marker coordinates line up exactly with the picture.
        self._map_inner = Gtk.Overlay()
        self._map_inner.set_hexpand(True)
        self._map_inner.set_vexpand(True)
        self._map_inner.set_child(self._map_pic)
        self._map_inner.add_overlay(self._map_marker)

        self._map_frame = Gtk.AspectFrame(ratio=2.0, obey_child=False)
        self._map_frame.set_hexpand(True)
        self._map_frame.set_vexpand(True)
        self._map_frame.set_halign(Gtk.Align.CENTER)
        self._map_frame.set_valign(Gtk.Align.CENTER)
        self._map_frame.set_child(self._map_inner)

        self._map_overlay = Gtk.Overlay()
        self._map_overlay.set_hexpand(True)
        self._map_overlay.set_vexpand(True)
        self._map_overlay.set_child(self._map_frame)
        self._map_overlay.add_overlay(right)

        # map animation state
        self._map_visible = False
        self._map_marker_pos = None
        self._map_target = None
        self._map_arrive = None
        self._map_anim = None
        self._map_shown_cc = None
        self._map_tick_id = None

        body.append(left)
        body.append(self._map_overlay)
        # Left column = a stable fraction of the window width (never half, even
        # when tiled narrow). Applied immediately and refined by a timer poll
        # (we avoid the size-allocate signal, which is unavailable / crashes on
        # some GTK4 builds).
        self._left_w = 280
        self._left.set_size_request(280, -1)
        GLib.timeout_add(250, self._poll_left_width)

        self._build_locations()

        # pick a default selected server if none
        if not self.selected:
            first = next(iter(self.servers.values())) if self.servers else {}
            if first:
                self.selected = next(iter(first.values()))["id"]
        self._refresh_selected_style()

    def _poll_left_width(self):
        # Keep the left column a stable fraction of the window width (polled on
        # a timer so we never touch layout during GTK's allocation phase, which
        # aborts on some GTK4 builds). Pure fraction with a cap — no high floor,
        # so it stays well under half even when the window is tiled narrow.
        if getattr(self, "window", None) is None or getattr(self, "_left", None) is None:
            return True
        w = self.window.get_width() or 900
        lw = min(300, max(120, int(w * 0.30)))
        if lw != self._left_w:
            self._left_w = lw
            self._left.set_size_request(lw, -1)
        return True

    def _segment(self, labels, active, on_pick):
        """Linked group of toggle buttons (works inside a Popover, unlike
        Adw.ComboRow whose nested dropdown does not render there)."""
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        box.add_css_class("linked")
        group = None
        for i, lbl in enumerate(labels):
            b = Gtk.ToggleButton(label=lbl)
            if group is not None:
                b.set_group(group)
            else:
                group = b
            b.set_active(i == active)
            b.connect("toggled",
                      lambda btn, idx=i, cb=on_pick: cb(idx) if btn.get_active() else None)
            box.append(b)
        return box

    def _build_menu(self):
        pop = Gtk.Popover()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(12)
        box.set_margin_end(12)

        proto_lbl = Gtk.Label(label="Connection Protocol", xalign=0)
        proto_lbl.add_css_class("dim-label")
        box.append(proto_lbl)
        box.append(self._segment(
            ["UDP — faster", "TCP — reliable"],
            0 if self.proto == "udp" else 1, self._on_proto))

        auto = Adw.SwitchRow(title="Auto-connect on launch")
        auto.set_active(bool(self.settings.get("auto_connect", False)))
        auto.connect("notify::active", self._on_auto_connect)
        box.append(auto)

        ks = Adw.SwitchRow(
            title="Firewall kill-switch",
            subtitle="Block all traffic unless it goes through the VPN")
        ks.set_active(self.kill_switch)
        ks.connect("notify::active", self._on_kill_switch)
        box.append(ks)

        sort_lbl = Gtk.Label(label="Sort servers", xalign=0)
        sort_lbl.add_css_class("dim-label")
        box.append(sort_lbl)
        box.append(self._segment(
            ["Default (by country)", "Latency (fastest first)"],
            1 if self.sort_mode == "latency" else 0, self._on_sort))

        scan = Gtk.Button(label="Scan latency")
        scan.connect("clicked", self._on_scan_latency)
        box.append(scan)

        about = Gtk.Button(label="About")
        about.connect("clicked", self._on_about)
        box.append(about)

        exit_btn = Gtk.Button(label="Exit")
        exit_btn.add_css_class("btn-disconnect")
        exit_btn.connect("clicked", lambda *_: self._quit_app())
        box.append(exit_btn)
        pop.set_child(box)
        return pop

    def _fav_key(self, srv):
        return f"{srv['id']}:{srv['proto']}"

    def _toggle_fav(self, srv):
        key = self._fav_key(srv)
        if key in self.favorites:
            self.favorites.discard(key)
        else:
            self.favorites.add(key)
        self.settings["favorites"] = sorted(self.favorites)
        save_json(SETTINGS_FILE, self.settings)
        self._build_locations()

    def _make_server_row(self, srv, cname):
        sub = f"{srv['cc'].upper()} · {srv['proto'].upper()}"
        row = Adw.ActionRow(title=srv["id"], activatable=True)
        row.add_css_class("server-row")
        row.set_subtitle(sub)
        row.connect("activated", lambda _r, s=srv: self._connect(s))
        key = self._fav_key(srv)
        star = Gtk.Button()
        star.set_has_frame(False)
        star.set_icon_name("starred-symbolic" if key in self.favorites
                           else "non-starred-symbolic")
        star.set_tooltip_text("Unpin from top" if key in self.favorites
                              else "Pin to top")
        star.connect("clicked", lambda _b, s=srv: self._toggle_fav(s))
        row.add_suffix(star)
        # live latency readout (populated by the background ping scan)
        lat = Gtk.Label()
        lat.add_css_class("mono")
        lat.add_css_class("dl")
        lat.set_tooltip_text("Round-trip latency")
        row.add_suffix(lat)
        self._latency_labels[self._fav_key(srv)] = lat
        ms = self.latency.get(self._fav_key(srv))
        if ms is not None:
            lat.set_text(f"{ms:.0f} ms")
        self.server_rows.append((srv["id"], cname, row))
        # restore the previously-selected server entry (id + protocol)
        if self.selected and srv["id"] == self.selected \
                and srv["proto"] == self.settings.get("last_proto", self.proto):
            self.selected_entry = srv
        return row

    def _build_locations(self):
        for child in list(self.loc_box):
            self.loc_box.remove(child)
        self.server_rows.clear()
        self.country_expanders.clear()
        self._latency_labels.clear()

        if not self.servers:
            lbl = Gtk.Label(
                label="No server files yet.\nUse “Add server files…” above to import your *.ovpn configs.")
            lbl.set_margin_top(12)
            lbl.set_wrap(True)
            lbl.add_css_class("dim-label")
            self.loc_box.append(lbl)
            return

        # Favorites section — pinned servers from any country, shown first.
        fav_srvs = [srv for cname in sorted(self.servers)
                    for srv in self.servers[cname]
                    if self._fav_key(srv) in self.favorites]
        if self.sort_mode == "latency":
            fav_srvs = sorted(fav_srvs, key=self._by_latency)
        if fav_srvs:
            exp = Adw.ExpanderRow(title="Favorites")
            exp.add_css_class("expander")
            exp.add_css_class("fastest-row")
            exp.set_subtitle(f"{len(fav_srvs)} pinned")
            exp.set_expanded(True)
            for srv in fav_srvs:
                exp.add_row(self._make_server_row(srv, srv["cc"]))
            self.loc_box.append(exp)

        # Country sections (favorited entries already live in Favorites).
        for cname in sorted(self.servers):
            entries = [s for s in self.servers[cname]
                       if self._fav_key(s) not in self.favorites]
            if not entries:
                continue
            if self.sort_mode == "latency":
                entries = sorted(entries, key=self._by_latency)
            exp = Adw.ExpanderRow(title=cname)
            exp.add_css_class("expander")
            exp.set_subtitle(f"{len(entries)} servers")
            self.country_expanders[cname] = exp
            for srv in entries:
                exp.add_row(self._make_server_row(srv, cname))
            self.loc_box.append(exp)

    # ----- latency scan + sorting -----
    def _by_latency(self, srv):
        ms = self.latency.get(self._fav_key(srv))
        # unknown latencies sort last
        return (ms is None, ms if ms is not None else 1e9)

    def _resolve(self, srv):
        """Resolve the server hostname to an IP (cached). Used by the
        firewall kill-switch, which needs a real address for `ip daddr`."""
        if srv.get("ip"):
            return srv["ip"]
        host = srv.get("host")
        if not host:
            return None
        try:
            import socket
            ip = socket.gethostbyname(host)
            srv["ip"] = ip
            return ip
        except Exception:
            return None

    @staticmethod
    def _ping_ip(host, timeout=1):
        """Return round-trip time in ms for one ICMP ping, or None on failure."""
        try:
            out = subprocess.run(
                ["ping", "-c", "1", "-w", str(timeout), host],
                capture_output=True, text=True, timeout=timeout + 2)
        except Exception:
            return None
        for line in out.stdout.splitlines():
            if "time=" in line:
                try:
                    return float(line.split("time=")[1].split()[0])
                except (ValueError, IndexError):
                    return None
        return None

    @staticmethod
    def _tcp_latency(host, port, timeout=2):
        """Fallback latency: time a TCP connect to the VPN port. Many VPN
        servers filter ICMP, so this often works when ping doesn't."""
        import socket
        try:
            t0 = time.monotonic()
            with socket.create_connection((host, port), timeout=timeout):
                return (time.monotonic() - t0) * 1000.0
        except Exception:
            return None

    def _scan_latency(self):
        """Measure each server's latency in the background and update rows."""
        if not self.servers:
            return
        srvs = [s for c in self.servers.values() for s in c]
        try:
            from concurrent.futures import ThreadPoolExecutor

            def measure(s):
                host = s.get("host")
                if not host:
                    return None
                ms = self._ping_ip(host)
                if ms is None:
                    ms = self._tcp_latency(host, s.get("port", 1194))
                return ms

            with ThreadPoolExecutor(max_workers=24) as ex:
                futs = {ex.submit(measure, s): self._fav_key(s) for s in srvs}
                for f in futs:
                    sid = futs[f]
                    try:
                        ms = f.result()
                    except Exception:
                        ms = None
                    self.latency[sid] = ms
                    GLib.idle_add(self._update_row_latency, sid, ms)
        except Exception:
            pass
        if self.sort_mode == "latency":
            GLib.idle_add(self._build_locations)

    def _update_row_latency(self, sid, ms):
        lbl = self._latency_labels.get(sid)
        if lbl is not None:
            lbl.set_text(f"{ms:.0f} ms" if ms is not None else "—")
        return False

    def _on_sort(self, idx):
        self.sort_mode = "latency" if idx == 1 else "default"
        self.settings["sort"] = self.sort_mode
        save_json(SETTINGS_FILE, self.settings)
        self._build_locations()

    def _on_scan_latency(self, btn):
        self._toast("Scanning latency…")
        threading.Thread(target=self._scan_latency, daemon=True).start()

    def _on_kill_switch(self, row, *a):
        self.kill_switch = row.get_active()
        self.settings["kill_switch"] = self.kill_switch
        save_json(SETTINGS_FILE, self.settings)
        if not self.kill_switch:
            self._kill_switch_off()
            self._toast("Kill-switch off")
        else:
            # engage immediately if we're already connected
            if tun_up() and self.active.get("ip"):
                try:
                    subprocess.Popen(
                        ["pkexec", HELPER, "killswitch-on", self.active["ip"]],
                        start_new_session=True)
                except Exception:
                    pass
            self._toast("Kill-switch armed (engages on connect)")

    # ----- credentials (in-app setup) -----
    # Both the "saved" row and the edit form are built ONCE; we only toggle
    # their visibility. This way the box can never end up empty (which is what
    # made the section appear to "vanish" when rebuilding from scratch).
    def _build_credentials_widgets(self):
        # Saved row
        self._creds_saved_row = Adw.ActionRow(
            title="Credentials",
            subtitle="Saved in ~/.config/nordgui/credentials")
        self._creds_saved_row.set_activatable(False)
        edit_btn = Gtk.Button(label="Edit")
        edit_btn.connect("clicked", lambda *_: self._show_creds_edit())
        self._creds_saved_row.add_suffix(edit_btn)
        self._creds_box.append(self._creds_saved_row)

        # Edit form
        self._creds_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self._creds_card.add_css_class("card")
        hint = Gtk.Label(label="Add your credentials")
        hint.add_css_class("hero-sub")
        self._creds_card.append(hint)

        self._creds_user = Gtk.Entry()
        self._creds_user.set_placeholder_text("NordVPN username / email")
        self._creds_pass = Gtk.Entry()
        self._creds_pass.set_visibility(False)
        self._creds_pass.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        self._creds_pass.set_placeholder_text("Password")
        self._creds_card.append(self._creds_user)
        self._creds_card.append(self._creds_pass)

        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        save = Gtk.Button(label="Save credentials")
        save.add_css_class("btn-connect")
        save.connect("clicked", self._on_save_creds)
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_: self._refresh_credentials_ui())
        btns.append(save)
        btns.append(cancel)
        self._creds_card.append(btns)

        self._creds_box.append(self._creds_card)
        self._refresh_credentials_ui()

    def _refresh_credentials_ui(self):
        """Show the saved row if creds exist, else the empty edit form."""
        has = os.path.exists(CREDS_FILE)
        self._creds_saved_row.set_visible(has)
        self._creds_card.set_visible(not has)
        if not has:
            self._creds_user.set_text("")
            self._creds_pass.set_text("")

    def _show_creds_edit(self):
        """Show the edit form, prefilled with the current creds if present."""
        self._creds_user.set_text("")
        self._creds_pass.set_text("")
        if os.path.exists(CREDS_FILE):
            try:
                with open(CREDS_FILE) as f:
                    lines = f.read().splitlines()
                if lines:
                    self._creds_user.set_text(lines[0])
                if len(lines) > 1:
                    self._creds_pass.set_text(lines[1])
            except OSError:
                pass
        self._creds_saved_row.set_visible(False)
        self._creds_card.set_visible(True)

    def _on_save_creds(self, btn):
        user = (self._creds_user.get_text() or "").strip()
        pw = self._creds_pass.get_text() or ""
        if not user or not pw:
            self._toast("Enter both username and password")
            return
        os.makedirs(NORDGUI_DIR, exist_ok=True)
        with open(CREDS_FILE, "w") as f:
            f.write(f"{user}\n{pw}\n")
        self._toast("Credentials saved")
        self._refresh_credentials_ui()

    # ----- add server files (file chooser -> copy into base folder) -----
    def _on_add_servers(self, btn):
        dlg = Gtk.FileChooserDialog(
            title="Select OpenVPN server files",
            transient_for=self.window,
            action=Gtk.FileChooserAction.OPEN,
        )
        dlg.set_select_multiple(True)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dlg.add_button("Add", Gtk.ResponseType.ACCEPT)
        flt = Gtk.FileFilter()
        flt.set_name("OpenVPN configs (*.ovpn)")
        flt.add_pattern("*.ovpn")
        dlg.add_filter(flt)
        dlg.connect("response", self._on_add_servers_response)
        dlg.present()

    def _on_add_servers_response(self, dlg, resp):
        if resp == Gtk.ResponseType.ACCEPT:
            os.makedirs(SERVERS_DIR, exist_ok=True)
            added = 0
            for gf in dlg.get_files():
                path = gf.get_path()
                if path and path.lower().endswith(".ovpn"):
                    try:
                        shutil.copyfile(
                            path, os.path.join(SERVERS_DIR, os.path.basename(path)))
                        added += 1
                    except OSError:
                        pass
            self.servers = discover_servers()
            self._build_locations()
            if added:
                self._toast(f"Added {added} server file(s)")
            else:
                self._toast("No .ovpn files selected")
        dlg.destroy()

    def _on_proto(self, idx):
        self.proto = "udp" if idx == 0 else "tcp"
        self.settings["proto"] = self.proto
        save_json(SETTINGS_FILE, self.settings)

    def _on_auto_connect(self, row, *a):
        self.settings["auto_connect"] = row.get_active()
        save_json(SETTINGS_FILE, self.settings)

    def _on_search(self, entry):
        q = entry.get_text().strip().lower()
        for sid, cname, row in self.server_rows:
            match = (not q) or (q in sid.lower()) or (q in cname.lower())
            row.set_visible(match)
        for cname, exp in self.country_expanders.items():
            any_visible = any(
                row.get_visible() for sid, c, row in self.server_rows if c == cname
            )
            exp.set_visible(any_visible)
            if q and any_visible:
                exp.set_expanded(True)

    def _refresh_selected_style(self):
        for sid, cname, row in self.server_rows:
            if sid == self.selected:
                row.add_css_class("accent")
            else:
                row.remove_css_class("accent")

    def _clear_selected_style(self):
        for sid, cname, row in self.server_rows:
            row.remove_css_class("accent")

    # ----- actions -----
    def _connect(self, srv):
        self.selected = srv["id"]
        self.selected_entry = srv
        self.settings["last_server"] = srv["id"]
        self.settings["last_proto"] = srv["proto"]
        save_json(SETTINGS_FILE, self.settings)
        self._refresh_selected_style()

        config = srv.get("path")
        proto = srv.get("proto")
        if not config or not os.path.exists(config):
            self._toast("Config file missing")
            return
        if not os.path.exists(CREDS_FILE):
            self._toast("Add your credentials first")
            return
        ip = self._resolve(srv)
        self.active = {
            "server": srv["id"], "cc": srv["cc"], "config": config,
            "proto": proto, "ip": ip, "started": int(time.time()),
        }
        save_json(ACTIVE_FILE, self.active)
        try:
            subprocess.Popen(
                ["pkexec", HELPER, "connect", config, CREDS_FILE, proto],
                start_new_session=True,
            )
            self._toast(f"Connecting to {srv['id']} ({proto.upper()})…")
        except Exception as e:
            self._toast(f"Failed: {e}")
        # firewall kill-switch: only allow traffic through the tunnel (+ the
        # VPN server itself so the tunnel can establish). If we can't pin the
        # server IP we skip it rather than risk a broken/leaky ruleset.
        if self.kill_switch:
            if ip:
                try:
                    subprocess.Popen(
                        ["pkexec", HELPER, "killswitch-on", ip],
                        start_new_session=True)
                except Exception:
                    pass
            else:
                self._toast("Kill-switch skipped: server IP unknown")

    def _kill_switch_off(self):
        try:
            subprocess.Popen(["pkexec", HELPER, "killswitch-off"],
                             start_new_session=True)
        except Exception:
            pass

    def _disconnect(self):
        try:
            subprocess.Popen(["pkexec", HELPER, "disconnect"],
                             start_new_session=True)
            self._toast("Disconnecting…")
        except Exception as e:
            self._toast(f"Failed: {e}")
        self._kill_switch_off()
        if os.path.exists(ACTIVE_FILE):
            os.remove(ACTIVE_FILE)
        self.active = {}

    def _on_big_btn(self, btn):
        if tun_up() or getattr(self, "_connecting", False):
            self._disconnect()
        elif getattr(self, "selected_entry", None):
            self._connect(self.selected_entry)
        else:
            self._toast("Select a server first")

    def _on_about(self, btn):
        d = Adw.AboutWindow(transient_for=self.window)
        d.set_application_name("NordVPN GUI")
        d.set_version("1.1")
        d.set_developer_name("linuxer")
        d.set_comments("OpenVPN front-end for NordVPN manual configs")
        d.set_application_icon("nordvpn-on-symbolic")
        d.present()

    # ----- status tick -----
    # ----- world-map background (animated marker) -----
    def _show_country(self, cc):
        coords = COUNTRY_COORDS.get(cc)
        if not coords:
            return
        lat, lon = coords
        tx = (lon + 180) / 360.0 * MAP_W
        ty = (90 - lat) / 180.0 * MAP_H
        self._map_target = (tx, ty)
        self._map_shown_cc = cc
        start = self._map_marker_pos or (MAP_W / 2.0, MAP_H * 0.5)
        self._map_anim = {"t0": time.time(), "dur": 1.15,
                          "from": start, "to": (tx, ty)}
        self._map_visible = True
        if self._map_tick_id is None:
            self._map_tick_id = self._map_marker.add_tick_callback(self._map_tick)

    def _hide_map(self):
        self._map_visible = False
        self._map_shown_cc = None
        self._map_marker_pos = None
        self._map_anim = None
        self._map_arrive = None
        self._map_pic.set_opacity(0)
        self._map_marker.queue_draw()
        if self._map_tick_id is not None:
            self._map_marker.remove_tick_callback(self._map_tick_id)
            self._map_tick_id = None

    def _map_tick(self, widget, clock):
        now = time.time()
        target_op = 0.6
        if self._map_anim:
            p = min(1.0, (now - self._map_anim["t0"]) / self._map_anim["dur"])
            e = 1 - (1 - p) ** 3  # easeOutCubic
            fx = self._map_anim["from"][0]
            fy = self._map_anim["from"][1]
            tx = self._map_anim["to"][0]
            ty = self._map_anim["to"][1]
            self._map_marker_pos = (fx + (tx - fx) * e, fy + (ty - fy) * e)
            self._map_pic.set_opacity(target_op * e)
            if p >= 1.0:
                self._map_anim = None
                self._map_arrive = now
        elif self._map_pic.get_opacity() != target_op:
            self._map_pic.set_opacity(target_op)
        self._map_marker.queue_draw()
        return self._map_visible  # keep ticking while visible (for the pulse)

    def _map_ll_to_xy(self, lat, lon, s, ox, oy):
        px = (lon + 180) / 360.0 * MAP_W
        py = (90 - lat) / 180.0 * MAP_H
        return ox + px * s, oy + py * s

    @staticmethod
    def _draw_label(cr, x, y, text, size, rgba, alpha, bold=False,
                    anchor="center"):
        cr.save()
        cr.select_font_face(
            "Sans", cairo.FONT_SLANT_NORMAL,
            cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
        cr.set_font_size(size)
        ext = cr.text_extents(text)
        tx = x - (ext.width / 2 + ext.x_bearing) if anchor == "center" else x
        cr.set_source_rgba(rgba[0], rgba[1], rgba[2], alpha)
        cr.move_to(tx, y)
        cr.show_text(text)
        cr.restore()

    def _draw_marker(self, area, cr, w, h):
        if not self._map_visible or self._map_marker_pos is None:
            return
        px, py = self._map_marker_pos
        a_t = MAP_W / MAP_H
        a_w = (w / h) if h else a_t
        if a_w > a_t:
            s = w / MAP_W
            ox = 0.0
            oy = (h - MAP_H * s) / 2.0
        else:
            s = h / MAP_H
            oy = 0.0
            ox = (w - MAP_W * s) / 2.0

        # --- country + continent labels across the whole map ---
        grey = (0.60, 0.63, 0.65)       # theme grey
        for cc, (lat, lon) in COUNTRY_COORDS.items():
            lx, ly = self._map_ll_to_xy(lat, lon, s, ox, oy)
            self._draw_label(cr, lx, ly + 3, COUNTRY_NAMES.get(cc, cc.upper()),
                             11, grey, 0.55)
        for cont, (lat, lon) in CONTINENT_COORDS.items():
            lx, ly = self._map_ll_to_xy(lat, lon, s, ox, oy)
            self._draw_label(cr, lx, ly, cont, 15, grey, 0.40, bold=True)

        X = ox + px * s
        Y = oy + py * s

        if getattr(self, "_connecting", False):
            r, g, b = 0.79, 0.62, 0.27  # amber while connecting
        else:
            r, g, b = 0.25, 0.82, 0.42  # green when connected

        # soft glow
        pat = cairo.RadialGradient(X, Y, 0, X, Y, 18)
        pat.add_color_stop_rgba(0, r, g, b, 0.95)
        pat.add_color_stop_rgba(1, r, g, b, 0.0)
        cr.set_source(pat)
        cr.arc(X, Y, 18, 0, 2 * math.pi)
        cr.fill()

        # bright core
        cr.set_source_rgba(r, g, b, 1.0)
        cr.arc(X, Y, 4, 0, 2 * math.pi)
        cr.fill()

        if getattr(self, "_connecting", False):
            # rotating dashed arc (spinner) while the tunnel comes up
            phase = (time.time() * 2.0) % 1.0
            cr.set_source_rgba(r, g, b, 0.9)
            cr.set_line_width(2)
            cr.arc(X, Y, 11, phase * 2 * math.pi,
                   phase * 2 * math.pi + 1.4 * math.pi)
            cr.stroke()
        else:
            # expanding pulse ring after arrival
            if self._map_arrive is not None:
                dt = time.time() - self._map_arrive
                phase = dt % 1.6
                rr = 12 + phase * 26
                alpha = max(0.0, 0.45 - (phase / 1.6) * 0.45)
                cr.set_source_rgba(r, g, b, alpha)
                cr.set_line_width(2)
                cr.arc(X, Y, rr, 0, 2 * math.pi)
                cr.stroke()

        # --- active country / continent label next to the marker ---
        if self._map_shown_cc:
            cname = COUNTRY_NAMES.get(self._map_shown_cc,
                                      self._map_shown_cc.upper())
            cont = COUNTRY_CONTINENT.get(self._map_shown_cc, "")
            label = f"{cname} · {cont}" if cont else cname
            ly = min(Y + 22, h - 4)
            # soft pill behind the label for readability
            cr.save()
            cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL,
                                cairo.FONT_WEIGHT_BOLD)
            cr.set_font_size(14)
            ext = cr.text_extents(label)
            cr.set_source_rgba(0.05, 0.06, 0.07, 0.6)
            cr.rectangle(X - ext.width / 2 - 6, ly - ext.height - 2,
                         ext.width + 12, ext.height + 6)
            cr.fill()
            cr.restore()
            # label on top of the pill
            self._draw_label(cr, X, ly, label, 14, (r, g, b), 1.0, bold=True)

    def _tick(self):
        connected = tun_up()
        connecting = (not connected) and bool(openvpn_pid())
        self._connecting = connecting
        self.dot.set_state(
            "connecting" if connecting else ("connected" if connected else "disconnected"))
        if connected:
            self.status_label.set_label("Connected")
            self.card.add_css_class("connected")
            self.big_btn.set_label("Disconnect")
            self.big_btn.remove_css_class("btn-connect")
            self.big_btn.add_css_class("btn-disconnect")
            srv = self.active.get("server") or openvpn_server_id()
            self.status_sub.set_label(country_of(srv) or "VPN active")
        elif connecting:
            self.status_label.set_label("Connecting…")
            self.card.remove_css_class("connected")
            self.big_btn.set_label("Cancel")
            self.big_btn.remove_css_class("btn-connect")
            self.big_btn.add_css_class("btn-disconnect")
            srv = self.active.get("server")
            self.status_sub.set_label(country_of(srv) or "Establishing tunnel…")
        else:
            self.status_label.set_label("Disconnected")
            self.card.remove_css_class("connected")
            self.big_btn.set_label("Connect")
            self.big_btn.remove_css_class("btn-disconnect")
            self.big_btn.add_css_class("btn-connect")
            sel = self.selected or "—"
            self.status_sub.set_label(f"Selected: {sel}")

        # selection highlight only while disconnected (clear once a tunnel is
        # up or coming up, so the accent line doesn't linger on a server row)
        if connected or connecting:
            self._clear_selected_style()
        else:
            self._refresh_selected_style()

        # world-map marker follows the (connecting or connected) country
        if (connected or connecting) and self.active.get("cc"):
            cc = self.active["cc"]
            if self._map_shown_cc != cc:
                self._show_country(cc)
        elif not connected and not connecting and self._map_visible:
            self._hide_map()

        # server name
        srv = (self.active.get("server") or openvpn_server_id()) if connected else None
        self._set_row(self.lbl_server, srv or "—")

        # DNS
        self._set_row(self.lbl_dns, read_dns() if connected else "—")

        # speed
        rx, tx = tun_stats()
        now = time.time()
        dl = ul = 0.0
        if connected and rx is not None and self.prev_rx is not None:
            dt = now - self.prev_ts
            dl = (rx - self.prev_rx) / dt if dt > 0 else 0
            ul = (tx - self.prev_tx) / dt if dt > 0 else 0
            self._set_row(self.lbl_dl, fmt_speed(max(0, dl)))
            self._set_row(self.lbl_ul, fmt_speed(max(0, ul)))
        elif connected:
            self._set_row(self.lbl_dl, "—")
            self._set_row(self.lbl_ul, "—")
        else:
            self._set_row(self.lbl_dl, "—")
            self._set_row(self.lbl_ul, "—")
        self.prev_rx, self.prev_tx, self.prev_ts = rx, tx, now

        # bandwidth history for the sparkline
        if connected:
            self.dl_hist.append(max(0, dl))
            self.ul_hist.append(max(0, ul))
            if len(self.dl_hist) > 60:
                self.dl_hist.pop(0)
                self.ul_hist.pop(0)
        else:
            self.dl_hist.clear()
            self.ul_hist.clear()
        self._spark.queue_draw()

        # leak guard — warn if we intended to be connected but the tunnel is
        # gone and openvpn is no longer running (unexpected drop)
        intended = bool(self.active.get("server"))
        if intended and not connected and not connecting:
            if not self._leak_warned:
                self._leak_warned = True
                self._toast("VPN dropped — your traffic is no longer protected!")
            self.status_label.set_label("Connection lost")
            self.status_sub.set_label("Leak risk — reconnect or disconnect")
        elif not intended:
            self._leak_warned = False

        # uptime
        if connected:
            secs = None
            if self.active.get("started"):
                secs = int(now - self.active["started"])
            else:
                secs = openvpn_uptime()
            if secs is not None:
                h, m = divmod(secs, 3600)
                mm, s = divmod(m, 60)
                self._set_row(self.lbl_up, f"{h:d}h {mm:02d}m" if h else f"{mm:d}m {s:02d}s")
            else:
                self._set_row(self.lbl_up, "—")
        else:
            self._set_row(self.lbl_up, "—")

        # public IP (throttled, threaded)
        if connected:
            if now - self.ip_cache_ts > 30:
                self.ip_cache_ts = now
                threading.Thread(target=self._ip_worker, daemon=True).start()
            self._set_row(self.lbl_ip, self.ip_cache or "…")
        else:
            self.ip_cache = None
            self.ip_cache_ts = 0
            self._set_row(self.lbl_ip, "—")

        # tray
        if getattr(self, "tray", None):
            self.tray.set_connected(connected)
            state_key = (connected, connecting)
            if getattr(self, "_tray_state", None) != state_key:
                self._tray_state = state_key
                self.tray.update_layout()
        return GLib.SOURCE_CONTINUE

    def _ip_worker(self):
        ip = fetch_public_ip()
        self.ip_cache = ip
        GLib.idle_add(lambda: self._set_row(self.lbl_ip, ip) or False)

    def _copy_ip(self, row):
        ip = (self.lbl_ip.get_text() or "").strip()
        if ip and ip not in ("—", "…"):
            self.window.get_clipboard().set_text(ip)
            self._toast(f"Copied IP: {ip}")
        else:
            self._toast("No IP to copy yet")

    def _draw_spark(self, area, cr, w, h, *args):
        cr.set_source_rgba(0.05, 0.06, 0.07, 1.0)
        cr.rectangle(0, 0, w, h)
        cr.fill()
        if not self.dl_hist:
            return
        peak = max(max(self.dl_hist), max(self.ul_hist), 1.0)
        pad = 3

        def _line(hist, rgba):
            n = len(hist)
            cr.set_source_rgba(*rgba)
            cr.set_line_width(1.5)
            cr.move_to(pad, h - pad)
            for i, v in enumerate(hist):
                x = pad + (w - 2 * pad) * (i / max(1, n - 1))
                y = h - pad - (h - 2 * pad) * (v / peak)
                cr.line_to(x, y)
            cr.stroke()

        _line(self.ul_hist, (0.60, 0.63, 0.65, 0.9))   # upload (grey)
        _line(self.dl_hist, (0.25, 0.82, 0.42, 1.0))   # download (green)

    def _set_row(self, lbl, text):
        lbl.set_text(str(text))

    # ----- tray -----
    def _build_tray(self):
        try:
            self.tray = Tray(
                on_open=lambda: self.window.present(),
                on_disconnect=self._disconnect,
                on_quit=self._quit_app,
                get_status=self._tray_status,
                on_toggle=self._on_big_btn,
            )
        except Exception as e:
            print("tray init failed:", e)
            self.tray = None

    def _tray_status(self):
        connected = tun_up()
        connecting = (not connected) and bool(openvpn_pid())
        if connected:
            label = f"Connected · {country_of(self.active.get('server')) or 'VPN'}"
        elif connecting:
            label = "Connecting…"
        else:
            label = "Disconnected"
        return {"connected": connected, "label": label}

    # ----- close to tray -----
    def _on_close(self, win):
        if getattr(self, "tray", None):
            win.hide()
            return True  # intercepted — do not destroy
        return False

    def _quit_app(self):
        """Completely disconnect the VPN and terminate the app (no tray)."""
        try:
            subprocess.Popen(["pkexec", HELPER, "disconnect"],
                             start_new_session=True)
        except Exception:
            pass
        self._kill_switch_off()
        if os.path.exists(ACTIVE_FILE):
            try:
                os.remove(ACTIVE_FILE)
            except OSError:
                pass
        self.active = {}
        self.quit()

    def _toast(self, msg):
        self.toast.add_toast(Adw.Toast(title=msg))


def main():
    import sys
    import traceback

    log = os.path.expanduser("~/nordvpn-gui.log")

    def _exchook(etype, value, tb):
        try:
            with open(log, "a") as f:
                f.write("=== uncaught exception ===\n")
                traceback.print_exception(etype, value, tb, file=f)
        except Exception:
            pass

    sys.excepthook = _exchook
    app = NordVPN()
    app.run()


if __name__ == "__main__":
    main()
