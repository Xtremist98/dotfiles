#!/usr/bin/env bash
# Root helper for nordvpn-gui. Invoked via pkexec (passwordless via polkit rule).
# Must be owned by root and not group/world writable for pkexec to allow it.
set -u

if [ "$#" -lt 1 ]; then
    echo "usage: $0 connect|disconnect|status|killswitch-on|killswitch-off [config] [creds]" >&2
    exit 1
fi

ACTION="$1"

case "$ACTION" in
    connect)
        CONFIG="$2"
        CREDS="$3"
        # tear down any existing tunnel first
        pkill -f "openvpn --config" 2>/dev/null
        sleep 0.4
        exec openvpn \
            --config "$CONFIG" \
            --auth-user-pass "$CREDS" \
            --block-ipv6 \
            --redirect-gateway def1 \
            --daemon \
            --log /tmp/nordvpn-gui.log
        ;;
    disconnect)
        pkill -f "openvpn --config" 2>/dev/null
        rm -f "${XDG_RUNTIME_DIR:-/run/user/$UID}/nordvpn-gui.pid" 2>/dev/null
        exit 0
        ;;
    status)
        if pgrep -x openvpn >/dev/null 2>&1; then
            echo connected
        else
            echo disconnected
        fi
        exit 0
        ;;
    killswitch-on)
        # $2 = VPN server IP to allow (so the tunnel can establish).
        # Block all outbound traffic EXCEPT loopback, already-established
        # connections, the tunnel itself, and the VPN server.
        SERVER="$2"
        if command -v nft >/dev/null 2>&1; then
            nft add table inet nordvpn_gui 2>/dev/null
            nft flush table inet nordvpn_gui 2>/dev/null
            nft add chain inet nordvpn_gui output '{ type filter hook output priority 0; policy accept; }' 2>/dev/null
            nft add rule inet nordvpn_gui output oifname "lo" accept
            nft add rule inet nordvpn_gui output ct state established,related accept
            nft add rule inet nordvpn_gui output oifname "tun0" accept
            [ -n "$SERVER" ] && nft add rule inet nordvpn_gui output ip daddr "$SERVER" accept
            nft add rule inet nordvpn_gui output reject
        elif command -v iptables >/dev/null 2>&1; then
            iptables -N nordvpn_gui 2>/dev/null
            iptables -F nordvpn_gui 2>/dev/null
            iptables -A nordvpn_gui -o lo -j ACCEPT
            iptables -A nordvpn_gui -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
            iptables -A nordvpn_gui -o tun0 -j ACCEPT
            [ -n "$SERVER" ] && iptables -A nordvpn_gui -d "$SERVER" -j ACCEPT
            iptables -A nordvpn_gui -j REJECT
            iptables -D OUTPUT -j nordvpn_gui 2>/dev/null
            iptables -I OUTPUT 1 -j nordvpn_gui
        else
            echo "no firewall backend (nft/iptables) available" >&2
            exit 1
        fi
        exit 0
        ;;
    killswitch-off)
        if command -v nft >/dev/null 2>&1; then
            nft delete table inet nordvpn_gui 2>/dev/null
        fi
        if command -v iptables >/dev/null 2>&1; then
            iptables -D OUTPUT -j nordvpn_gui 2>/dev/null
            iptables -F nordvpn_gui 2>/dev/null
            iptables -X nordvpn_gui 2>/dev/null
        fi
        exit 0
        ;;
esac
