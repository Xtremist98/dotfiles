#!/usr/bin/env bash
#
# NordGUI installer (tarball mode).
# Copies the app, helper, polkit rule, desktop entry and tray icons into a
# standard prefix (/usr/local by default) and makes them root-owned.
#
#   sudo ./install.sh            # installs to /usr/local
#   sudo PREFIX=/opt ./install.sh # installs to /opt
#
set -u
PREFIX="${PREFIX:-/usr/local}"
SHARE="$PREFIX/share/nordvpn-gui"
BIN="$PREFIX/bin"

# Must run as root (we install system files + a polkit rule).
if [ "$(id -u)" -ne 0 ]; then
    echo "Please run as root: sudo $0" >&2
    exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"

install -d "$SHARE" "$SHARE/icons" "$BIN" \
    "$PREFIX/share/applications" \
    "$PREFIX/share/polkit-1/rules.d"

install -m755 "$HERE/share/nordvpn-gui/nordvpn_gui.py" "$SHARE/nordvpn_gui.py"
install -m755 "$HERE/bin/nordvpn-gui" "$BIN/nordvpn-gui"
install -m755 "$HERE/share/nordvpn-gui/helper.sh" "$PREFIX/bin/nordvpn-gui-helper"
install -m644 "$HERE/share/nordvpn-gui/icons/"* "$SHARE/icons/"
install -m644 "$HERE/share/applications/nordvpn-gui.desktop" "$PREFIX/share/applications/"
install -m644 "$HERE/share/polkit-1/rules.d/50-nordvpn-gui.rules" "$PREFIX/share/polkit-1/rules.d/"

# Ensure the helper is owned by root (pkexec requires this).
chown root:root "$PREFIX/bin/nordvpn-gui-helper" 2>/dev/null || true
chmod 755 "$PREFIX/bin/nordvpn-gui-helper"

echo
echo "NordGUI installed to $PREFIX"
echo "  app:        $SHARE/nordvpn_gui.py"
echo "  launcher:   $BIN/nordvpn-gui"
echo "  helper:     $PREFIX/bin/nordvpn-gui-helper (root)"
echo "  polkit:     $PREFIX/share/polkit-1/rules.d/50-nordvpn-gui.rules"
echo
echo "Launch 'nordvpn-gui' from your menu, or run it from a terminal."
echo "First run will import any existing ~/nordvpn/*.ovpn + ~/.nordvpn-creds"
echo "into ~/.config/nordgui/.  Use 'Add server files…' to add more."
